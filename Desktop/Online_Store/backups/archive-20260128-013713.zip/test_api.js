// Simple test script to verify API integration
const axios = require('axios');

// Base URL for the backend API
const BASE_URL = 'http://127.0.0.1:8000';

async function testAPI() {
  console.log('Testing API Integration...\n');
  
  try {
    // Test 1: Health check
    console.log('1. Testing health endpoint...');
    const healthResponse = await axios.get(`${BASE_URL}/health`);
    console.log('✓ Health check passed:', healthResponse.data);
    
    // Test 2: Get products
    console.log('\n2. Testing products endpoint...');
    const productsResponse = await axios.get(`${BASE_URL}/products`);
    console.log('✓ Products endpoint works, received:', productsResponse.data.total, 'total products');
    
    // Test 3: Register a test user
    console.log('\n3. Testing user registration...');
    const registerData = {
      email: 'test@example.com',
      name: 'Test User',
      password: 'password123'
    };
    
    try {
      const registerResponse = await axios.post(`${BASE_URL}/auth/register`, registerData);
      console.log('✓ User registration successful:', registerResponse.data.user.name);
      
      // Extract token for future requests
      const token = registerResponse.data.access_token;
      const headers = { 'Authorization': `Bearer ${token}` };
      
      // Test 4: Get user profile
      console.log('\n4. Testing user profile endpoint...');
      const userResponse = await axios.get(`${BASE_URL}/users/${registerResponse.data.user.id}`, { headers });
      console.log('✓ User profile retrieved:', userResponse.data.name);
      
      // Test 5: Test cart functionality
      console.log('\n5. Testing cart functionality...');
      const userId = registerResponse.data.user.id;
      
      // Get user's cart (should be empty initially)
      const cartResponse = await axios.get(`${BASE_URL}/cart/${userId}`, { headers });
      console.log('✓ Cart retrieved:', cartResponse.data.total_items, 'items in cart');
      
      // If there are products, try adding one to cart
      if (productsResponse.data.data && productsResponse.data.data.length > 0) {
        const firstProduct = productsResponse.data.data[0];
        console.log(`   Attempting to add product "${firstProduct.name}" to cart...`);
        
        const addToCartResponse = await axios.post(
          `${BASE_URL}/cart/${userId}/items`, 
          { product_id: firstProduct.id, quantity: 1 }, 
          { headers }
        );
        console.log('✓ Product added to cart successfully');
      }
      
    } catch (regErr) {
      console.log('Note: Registration may have failed if user already exists:', regErr.response?.data?.detail || regErr.message);
    }
    
    console.log('\n✓ All API tests completed successfully!');
    
  } catch (error) {
    console.error('✗ API test failed:', error.response?.data || error.message);
  }
}

testAPI();