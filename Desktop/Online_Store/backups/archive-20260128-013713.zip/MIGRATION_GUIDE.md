# Database Migration Guide

## Overview

This guide walks through migrating from the in-memory database to the new SQLite persistent database implementation.

## Pre-Migration Checklist

- [ ] Backup current application data (if any)
- [ ] Stop both frontend and backend servers
- [ ] Create a backup of the entire project
- [ ] Ensure you have the latest code changes

## Migration Steps

### Step 1: Install New Dependencies

```bash
cd Backend_App
pip install -r requirements.txt
```

The new requirements include:
- `sqlalchemy` - ORM for easier database operations
- `alembic` - Database migration tool
- `passlib[bcrypt]` - Bcrypt password hashing
- Other security and testing dependencies

### Step 2: Create .env File

Copy and configure the environment file:

```bash
cd Backend_App
cp .env.example .env
```

Edit `.env` with your configuration:
```
ENVIRONMENT=development
SECRET_KEY=generate-a-strong-key-here
DATABASE_URL=sqlite:///ecommerce.db
```

Generate a strong SECRET_KEY:
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Step 3: Initialize Database

The database is automatically created on first run. To verify:

```bash
cd Backend_App
python -c "from database import db; print('Database initialized successfully')"
```

This will:
1. Create `ecommerce.db` SQLite file
2. Create all necessary tables
3. Create performance indexes
4. Populate 30 sample products

### Step 4: Verify Database Structure

Check that tables were created:

```bash
sqlite3 ecommerce.db
sqlite> .tables
# Should output:
# cart_items orders products users wishlist_items order_items
```

List table structure:

```bash
sqlite3 ecommerce.db ".schema products"
```

### Step 5: Update Frontend Configuration

Create `.env.local` file in Frontend directory:

```bash
cd Frontend_App/my-app
cp .env.local.example .env.local
```

Ensure `NEXT_PUBLIC_API_URL` points to your backend:
```
NEXT_PUBLIC_API_URL=http://localhost:8000
```

### Step 6: Test the Application

Start backend:
```bash
cd Backend_App
python -m uvicorn main:app --reload
```

Start frontend (in another terminal):
```bash
cd Frontend_App/my-app
npm run dev
```

Verify functionality:
1. Visit http://localhost:3000
2. Register a new user
3. Browse products
4. Add items to cart
5. Add items to wishlist
6. Create an order

### Step 7: Verify Data Persistence

Stop and restart the backend:
```bash
# Stop backend (Ctrl+C)
# Start again
python -m uvicorn main:app --reload
```

Check that:
- Your registered user still exists
- Products are still there
- Cart items persist (if implemented in services)

## Troubleshooting

### Database File Not Created

**Error**: `DatabaseError: [Errno 2] No such file or directory`

**Solution**:
```bash
# Ensure database directory is writable
cd Backend_App
python -c "from database import DatabaseConnection; db = DatabaseConnection()"
```

### Import Error: sqlalchemy not found

**Error**: `ModuleNotFoundError: No module named 'sqlalchemy'`

**Solution**:
```bash
pip install -r requirements.txt
```

### Port Already in Use

**Error**: `Address already in use`

**Solution**:
```bash
# Kill process on port 8000 (Linux/Mac)
lsof -ti:8000 | xargs kill -9

# Kill process on port 8000 (Windows)
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### Database Locked Error

**Error**: `database is locked`

**Solution**:
1. Check that only one instance of backend is running
2. Delete database and recreate:
   ```bash
   rm ecommerce.db
   python -c "from database import db; print('Database recreated')"
   ```

## Data Migration from In-Memory

If you have existing user data to preserve:

### Step 1: Export Current Data

Before replacing the database code, export your data:

```python
# Create export script
from services.user_service import UserService
from services.product_service import ProductService
import json

users_data = []
for user_id, user in UserService._users.items():
    users_data.append(user.to_dict())

products_data = []
for product_id, product in ProductService._products.items():
    products_data.append(product.to_dict())

# Save to files
with open('users_export.json', 'w') as f:
    json.dump(users_data, f, indent=2)

with open('products_export.json', 'w') as f:
    json.dump(products_data, f, indent=2)
```

### Step 2: Import Data into SQLite

After migration:

```python
import json
from database import db

# Import users
with open('users_export.json', 'r') as f:
    users = json.load(f)

for user_data in users:
    cursor = db.execute('''
        INSERT INTO users (email, name, password_hash, is_active, created_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        user_data['email'],
        user_data['name'],
        user_data['password_hash'],
        user_data['is_active'],
        user_data['created_at']
    ))

db.commit()
```

## Schema Changes from Old to New

### Old: In-Memory Storage
```python
class User:
    users: List[User] = []  # Stored in Python list

class Product:
    products: List[Product] = []  # Stored in Python list

class Order:
    orders: List[Order] = []  # Stored in Python list
```

### New: SQLite Database
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    -- ... persisted on disk
);

CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    -- ... persisted on disk
);

CREATE TABLE orders (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    -- ... persisted on disk
);
```

## Service Layer Updates Needed

The following service files need to be updated to use SQLite:

### 1. UserService (`services/user_service.py`)
Currently uses in-memory `_users` dict. Update to query database:

```python
@classmethod
def get_user_by_id(cls, user_id: int) -> Optional[User]:
    from database import db
    cursor = db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    if row:
        return User(
            id=row['id'],
            email=row['email'],
            name=row['name'],
            password_hash=row['password_hash'],
            is_active=row['is_active']
        )
    return None
```

### 2. ProductService (`services/product_service.py`)
Update product queries to use database.

### 3. CartService (`services/cart_service.py`)
Update to persist cart items to database instead of in-memory.

### 4. OrderService (`services/order_service.py`)
Update to use database for order storage.

### 5. WishlistService (`services/wishlist_service.py`)
Update to use database for wishlist items.

## Post-Migration Verification

### API Health Check
```bash
curl http://localhost:8000/health
# Expected response:
# {"status": "healthy", "service": "e-commerce-api"}
```

### Database Health Check
```bash
sqlite3 ecommerce.db "SELECT COUNT(*) as product_count FROM products;"
# Should show: 30 (from sample data)
```

### Full Integration Test
1. Register new user: POST /auth/register
2. Login: POST /auth/login
3. Get products: GET /products
4. Add to cart: POST /cart/{user_id}/items
5. Get cart: GET /cart/{user_id}
6. Create order: POST /orders

## Rollback Plan

If migration fails and you need to rollback:

### Step 1: Restore Backup
```bash
# If you backed up the old code
git checkout <old-commit-hash>
```

### Step 2: Restore Database (if keeping old structure)
```bash
# Remove new database
rm Backend_App/ecommerce.db

# Restore from backup or recreate in-memory
```

### Step 3: Restart Services
```bash
# Backend
python -m uvicorn Backend_App.main:app --reload

# Frontend
npm run dev
```

## Next Steps After Migration

1. **Update Services**: Update all service files to use database
2. **Test Thoroughly**: Test all features work with persistent storage
3. **Add Migrations**: Set up Alembic for future schema changes
4. **Backup Strategy**: Implement regular database backups
5. **Monitoring**: Set up database monitoring and logging

## Database Maintenance

### Backup Database
```bash
# Create backup
cp ecommerce.db ecommerce.backup.db

# Or use SQLite backup
sqlite3 ecommerce.db ".backup /tmp/ecommerce.backup.db"
```

### View Database Stats
```bash
sqlite3 ecommerce.db << EOF
SELECT name, COUNT(*) as count FROM (
    SELECT 'users' as name FROM users
    UNION ALL SELECT 'products' FROM products
    UNION ALL SELECT 'orders' FROM orders
);
EOF
```

### Reset Database (Development Only)
```bash
rm Backend_App/ecommerce.db
python -c "from Backend_App.database import db; print('Database reset')"
```

---

**Migration Duration**: ~30 minutes
**Difficulty**: Easy (mostly automatic)
**Downtime**: ~5 minutes during deployment
**Testing Required**: ~15 minutes

For support, refer to REFACTORING_ANALYSIS.md or IMPLEMENTATION_GUIDE.md
