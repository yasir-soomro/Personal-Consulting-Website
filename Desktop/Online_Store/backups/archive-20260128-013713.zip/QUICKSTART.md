# Quick Start Guide - E-Commerce Application

## ⚡ 5-Minute Setup

### Prerequisites
- Python 3.10+ installed
- Node.js 18+ installed
- Git (optional)

### Backend Setup (2 minutes)

```bash
# Navigate to backend directory
cd Backend_App

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env

# Start backend server
python -m uvicorn main:app --reload
```

**Backend should be running at**: `http://localhost:8000`

### Frontend Setup (2 minutes)

In another terminal:

```bash
# Navigate to frontend directory
cd Frontend_App/my-app

# Install dependencies
npm install

# Start frontend server
npm run dev
```

**Frontend should be running at**: `http://localhost:3000`

### 1-Minute Verification

1. Open http://localhost:3000 in your browser
2. Click "Register" button
3. Create a test account:
   - Email: `test@example.com`
   - Name: `Test User`
   - Password: `TestPass123`
4. Browse products
5. Add items to cart
6. Add items to wishlist

✅ **Application is working!**

---

## 📚 Documentation

- **[REFACTORING_ANALYSIS.md](./REFACTORING_ANALYSIS.md)** - Detailed analysis of all issues found
- **[REFACTORING_SUMMARY.md](./REFACTORING_SUMMARY.md)** - Summary of all changes made
- **[IMPLEMENTATION_GUIDE.md](./IMPLEMENTATION_GUIDE.md)** - Complete architecture guide
- **[MIGRATION_GUIDE.md](./MIGRATION_GUIDE.md)** - Database migration instructions

---

## 🚀 Key Features

### User Management
- ✅ User registration with validation
- ✅ Secure login with JWT authentication
- ✅ Persistent user sessions
- ✅ Password hashing with bcrypt

### Products
- ✅ Browse 30 sample products
- ✅ Advanced filtering and search
- ✅ Product categories
- ✅ Ratings and reviews ready

### Shopping Cart
- ✅ Add/remove items
- ✅ Update quantities
- ✅ Persistent cart storage
- ✅ Clear cart functionality

### Wishlist
- ✅ Save favorite products
- ✅ View wishlists
- ✅ Remove items
- ✅ Persistent storage

### Orders
- ✅ Create orders from cart
- ✅ View order history
- ✅ Order status tracking
- ✅ Order management

---

## 🔧 API Endpoints

### Authentication
```
POST   /auth/register      - Register new user
POST   /auth/login         - Login user
POST   /auth/token         - Get access token
```

### Products
```
GET    /products           - List products
GET    /products/{id}      - Get product details
GET    /products/slug/{slug} - Get product by slug
GET    /products/categories - Get all categories
```

### Cart
```
GET    /cart/{user_id}                    - Get cart
POST   /cart/{user_id}/items              - Add to cart
PUT    /cart/{user_id}/items/{product_id} - Update cart item
DELETE /cart/{user_id}/items/{product_id} - Remove from cart
DELETE /cart/{user_id}/clear              - Clear cart
GET    /cart/{user_id}/summary            - Get cart summary
```

### Wishlist
```
GET    /wishlist/{user_id}                      - Get wishlist
POST   /wishlist/{user_id}/items                - Add to wishlist
DELETE /wishlist/{user_id}/items/{product_id}   - Remove from wishlist
DELETE /wishlist/{user_id}/clear                - Clear wishlist
GET    /wishlist/{user_id}/product/{id}/check   - Check if in wishlist
```

### Orders
```
POST   /orders              - Create order
GET    /orders              - Get user's orders
GET    /orders/{id}         - Get order details
PUT    /orders/{id}/confirm - Confirm order
PUT    /orders/{id}/cancel  - Cancel order
```

### Health
```
GET    /health             - Server health check
GET    /                   - API info
```

---

## 🛠️ Development Commands

### Backend

```bash
# Run development server with auto-reload
python -m uvicorn main:app --reload

# Run with specific port
python -m uvicorn main:app --port 8001

# Run tests
pytest

# Format code
black Backend_App

# Lint code
flake8 Backend_App

# Type checking
mypy Backend_App
```

### Frontend

```bash
# Development server
npm run dev

# Build for production
npm run build

# Run production build
npm start

# Lint code
npm run lint

# Format code
npm run format
```

---

## 🔐 Security Notes

### Current Implementation
✅ JWT token authentication
✅ Bcrypt password hashing
✅ Environment variable configuration
✅ Input validation with Pydantic
✅ SQL injection prevention

### Recommended for Production
🔲 Enable HTTPS/SSL
🔲 Set strong SECRET_KEY
🔲 Configure CORS for your domain
🔲 Enable rate limiting
🔲 Add request validation middleware
🔲 Implement audit logging
🔲 Use strong database passwords
🔲 Regular security updates

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check if port 8000 is in use
lsof -i :8000  # macOS/Linux
netstat -ano | findstr :8000  # Windows

# Kill process and restart
kill <PID>
python -m uvicorn main:app --reload
```

### Frontend won't connect to backend
```bash
# Check .env.local file has correct API URL
cat Frontend_App/my-app/.env.local

# Should contain:
# NEXT_PUBLIC_API_URL=http://localhost:8000

# Restart frontend after changing
```

### Database errors
```bash
# Reset database
rm Backend_App/ecommerce.db

# Reinitialize
python -c "from Backend_App.database import db; print('Done')"

# Restart backend
python -m uvicorn main:app --reload
```

### Port conflicts
```bash
# Use different ports
python -m uvicorn main:app --port 8001  # Backend
npm run dev -- -p 3001  # Frontend
```

---

## 📊 Database

### Access Database
```bash
# Open SQLite CLI
sqlite3 Backend_App/ecommerce.db

# View tables
sqlite> .tables

# View products
sqlite> SELECT * FROM products;

# View users
sqlite> SELECT * FROM users;

# Exit
sqlite> .quit
```

### Database Location
- **File**: `Backend_App/ecommerce.db`
- **Size**: ~1-5MB (depends on data)
- **Backup**: Copy ecommerce.db to backup

---

## 📦 Project Structure

```
Online_Store/
├── Backend_App/                    # FastAPI backend
│   ├── main.py
│   ├── database.py                 # SQLite database layer
│   ├── requirements.txt
│   ├── .env.example
│   └── ...other files
│
├── Frontend_App/my-app/            # Next.js frontend
│   ├── src/
│   │   ├── api/                    # API clients
│   │   ├── app/                    # Pages
│   │   ├── components/             # React components
│   │   ├── context/                # Auth context
│   │   └── types/                  # TypeScript types
│   ├── package.json
│   └── .env.local.example
│
├── Documentation/
│   ├── REFACTORING_ANALYSIS.md     # Issues analysis
│   ├── REFACTORING_SUMMARY.md      # Changes summary
│   ├── IMPLEMENTATION_GUIDE.md     # Architecture guide
│   ├── MIGRATION_GUIDE.md          # Database migration
│   └── README.md                   # This file
│
└── Configuration/
    ├── START.ps1                   # Start both servers
    ├── SETUP.ps1                   # Install dependencies
    └── ...other config
```

---

## 🎯 Next Steps

1. **Explore the Application**
   - Create accounts and test all features
   - Add products to cart and wishlist
   - Create orders

2. **Review Documentation**
   - Read IMPLEMENTATION_GUIDE.md for architecture
   - Review REFACTORING_SUMMARY.md for what changed
   - Check MIGRATION_GUIDE.md if migrating data

3. **Customize**
   - Modify styles in `components/`
   - Update API endpoints if needed
   - Add your own features

4. **Deploy**
   - Follow deployment instructions in IMPLEMENTATION_GUIDE.md
   - Set up production environment variables
   - Configure CORS and security settings

---

## 💡 Tips

### Generate Strong Secret Key
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Check API Documentation
Visit `http://localhost:8000/docs` to see interactive Swagger UI

### View API Responses
Use curl or Postman to test endpoints:
```bash
curl http://localhost:8000/products
```

### Debug Frontend
- Open browser DevTools (F12)
- Check Network tab for API calls
- Check Console tab for errors

### Debug Backend
- Check terminal output for logs
- Use `print()` statements for debugging
- Set `DEBUG=True` in development

---

## 📞 Support

For detailed information:
- **Architecture**: See IMPLEMENTATION_GUIDE.md
- **Issues Fixed**: See REFACTORING_ANALYSIS.md
- **Database**: See MIGRATION_GUIDE.md
- **Changes**: See REFACTORING_SUMMARY.md

---

## ✨ Features Overview

| Feature | Status | Notes |
|---------|--------|-------|
| User Authentication | ✅ Complete | JWT-based, secure |
| Product Catalog | ✅ Complete | 30 sample products |
| Shopping Cart | ✅ Complete | Persistent storage |
| Wishlist | ✅ Complete | Save favorite items |
| Orders | ✅ Complete | Order management |
| Search/Filter | ✅ Complete | Advanced filtering |
| API Documentation | ✅ Complete | Swagger UI at /docs |
| Database Persistence | ✅ Complete | SQLite database |
| Error Handling | ✅ Complete | User-friendly messages |
| TypeScript Support | ✅ Complete | Full type safety |

---

## 🚀 Ready to Go!

Your e-commerce application is fully functional and ready to use. Start building amazing features! 🎉

**Questions or Issues?** Check the documentation files included in this project.

Happy coding! 💻
