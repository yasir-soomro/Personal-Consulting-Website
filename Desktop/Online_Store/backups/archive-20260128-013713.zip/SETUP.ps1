# Setup Script for E-Commerce Application
# Installs all dependencies for both backend and frontend

Write-Host "🔧 E-Commerce Application Setup" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Backend Setup
Write-Host "Setting up Backend..." -ForegroundColor Yellow
cd c:\Users\afzal\Desktop\Online_Store

Write-Host "Installing Python dependencies..." -ForegroundColor Gray
pip install fastapi uvicorn pydantic python-multipart httpx --quiet

Write-Host "✓ Backend dependencies installed" -ForegroundColor Green
Write-Host ""

# Frontend Setup
Write-Host "Setting up Frontend..." -ForegroundColor Yellow
cd c:\Users\afzal\Desktop\Online_Store\Frontend_App\my-app

Write-Host "Installing Node.js dependencies..." -ForegroundColor Gray
npm install --silent

Write-Host "✓ Frontend dependencies installed" -ForegroundColor Green
Write-Host ""

Write-Host "✓ Setup complete!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "1. Run: .\START.ps1" -ForegroundColor White
Write-Host "2. Open: http://localhost:3000" -ForegroundColor White
Write-Host ""
