# React Components - E-Commerce Frontend Examples

Complete React/TypeScript component examples for integrating with the FastAPI backend.

---

## 1. ProductCard Component

Reusable card for displaying individual products.

```typescript
// app/components/ProductCard.tsx
import Image from 'next/image';
import Link from 'next/link';
import { useState } from 'react';

interface ProductCardProps {
  id: number;
  name: string;
  slug: string;
  price: number;
  rating: number;
  images: string[];
  category: string;
  inStock: boolean;
  onAddToCart?: (productId: number, quantity: number) => Promise<void>;
}

export default function ProductCard({
  id,
  name,
  slug,
  price,
  rating,
  images,
  category,
  inStock,
  onAddToCart
}: ProductCardProps) {
  const [quantity, setQuantity] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [showNotification, setShowNotification] = useState(false);

  const handleAddToCart = async () => {
    if (!onAddToCart) return;
    
    try {
      setIsLoading(true);
      await onAddToCart(id, quantity);
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
      <div className="relative h-48 w-full bg-gray-100">
        <Image src={images[0]} alt={name} fill className="object-cover" />
      </div>
      <div className="p-4">
        <span className="inline-block bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full">
          {category}
        </span>
        <Link href={`/products/${slug}`}>
          <h3 className="text-lg font-bold text-gray-800 hover:text-blue-600 mt-2">
            {name}
          </h3>
        </Link>
        <div className="flex items-center mt-2">
          {[...Array(5)].map((_, i) => (
            <span key={i} className={i < Math.round(rating) ? 'text-yellow-400' : 'text-gray-300'}>
              ★
            </span>
          ))}
        </div>
        <span className="text-2xl font-bold text-gray-900 mt-3 block">${price.toFixed(2)}</span>
        {inStock && (
          <div className="flex gap-2 mt-4">
            <input
              type="number"
              min="1"
              max="10"
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-16 px-2 py-2 border border-gray-300 rounded"
            />
            <button
              onClick={handleAddToCart}
              disabled={isLoading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded"
            >
              {isLoading ? 'Adding...' : 'Add to Cart'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
```

---

## 2. ProductList Component

Display paginated and filtered products.

```typescript
// app/components/ProductList.tsx
'use client';

import { useState, useEffect } from 'react';
import ProductCard from './ProductCard';

interface Product {
  id: number;
  name: string;
  slug: string;
  price: number;
  rating: number;
  images: string[];
  category: string;
  in_stock: boolean;
}

interface ProductListProps {
  onAddToCart?: (productId: number, quantity: number) => Promise<void>;
}

export default function ProductList({ onAddToCart }: ProductListProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    minPrice: 0,
    maxPrice: 10000,
    minRating: 0,
    inStock: false,
    sortBy: 'id'
  });

  useEffect(() => {
    fetchProducts();
  }, [currentPage, filters]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        skip: ((currentPage - 1) * 10).toString(),
        limit: '10',
        search: filters.search,
        category: filters.category,
        min_price: filters.minPrice.toString(),
        max_price: filters.maxPrice.toString(),
        min_rating: filters.minRating.toString(),
        in_stock: filters.inStock.toString(),
        sort_by: filters.sortBy
      });

      const response = await fetch(`http://localhost:8000/api/products?${params}`);
      const data = await response.json();
      
      setProducts(data.data);
      setTotalPages(data.total_pages);
      setError(null);
    } catch (err) {
      setError('Failed to load products');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-md mb-6">
        <h2 className="text-xl font-bold mb-4">Filters</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input
            type="text"
            placeholder="Search products..."
            value={filters.search}
            onChange={(e) => { setFilters({...filters, search: e.target.value}); setCurrentPage(1); }}
            className="border border-gray-300 rounded px-4 py-2"
          />
          
          <select
            value={filters.category}
            onChange={(e) => { setFilters({...filters, category: e.target.value}); setCurrentPage(1); }}
            className="border border-gray-300 rounded px-4 py-2"
          >
            <option value="">All Categories</option>
            <option value="Electronics">Electronics</option>
            <option value="Fashion">Fashion</option>
            <option value="Home">Home</option>
            <option value="Beauty">Beauty</option>
            <option value="Sports">Sports</option>
            <option value="Books">Books</option>
          </select>

          <select
            value={filters.sortBy}
            onChange={(e) => { setFilters({...filters, sortBy: e.target.value}); setCurrentPage(1); }}
            className="border border-gray-300 rounded px-4 py-2"
          >
            <option value="id">Newest</option>
            <option value="price">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
            <option value="stock">Most In Stock</option>
            <option value="name">Name (A-Z)</option>
          </select>

          <label className="flex items-center border border-gray-300 rounded px-4 py-2">
            <input
              type="checkbox"
              checked={filters.inStock}
              onChange={(e) => { setFilters({...filters, inStock: e.target.checked}); setCurrentPage(1); }}
              className="mr-2"
            />
            In Stock Only
          </label>
        </div>
      </div>

      {/* Loading State */}
      {loading && <div className="text-center py-8">Loading products...</div>}

      {/* Error State */}
      {error && <div className="text-red-600 text-center py-8">{error}</div>}

      {/* Products Grid */}
      {!loading && products.length > 0 && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {products.map(product => (
              <ProductCard
                key={product.id}
                {...product}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center gap-4">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-4 py-2 bg-gray-300 rounded disabled:opacity-50"
            >
              Previous
            </button>
            <span className="px-4 py-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-4 py-2 bg-gray-300 rounded disabled:opacity-50"
            >
              Next
            </button>
          </div>
        </>
      )}

      {!loading && products.length === 0 && (
        <div className="text-center py-8 text-gray-600">No products found</div>
      )}
    </div>
  );
}
```

---

## 3. ShoppingCart Component

Display cart items and totals.

```typescript
// app/components/ShoppingCart.tsx
'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';

interface CartItem {
  product_id: number;
  product_name: string;
  quantity: number;
  price: number;
  total: number;
  image: string;
}

interface ShoppingCartProps {
  userId: number;
  accessToken?: string;
}

export default function ShoppingCart({ userId, accessToken }: ShoppingCartProps) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPrice, setTotalPrice] = useState(0);

  useEffect(() => {
    fetchCart();
  }, []);

  const fetchCart = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/cart/${userId}`, {
        headers: accessToken ? { 'Authorization': `Bearer ${accessToken}` } : {}
      });
      const data = await response.json();
      setItems(data.items);
      setTotalPrice(data.total_price);
    } catch (error) {
      console.error('Failed to fetch cart:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId: number, quantity: number) => {
    if (quantity < 1) {
      removeItem(productId);
      return;
    }

    try {
      const response = await fetch(
        `http://localhost:8000/api/cart/${userId}/items/${productId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            ...(accessToken && { 'Authorization': `Bearer ${accessToken}` })
          },
          body: JSON.stringify({ quantity })
        }
      );
      const data = await response.json();
      setItems(data.items);
      setTotalPrice(data.total_price);
    } catch (error) {
      console.error('Failed to update quantity:', error);
    }
  };

  const removeItem = async (productId: number) => {
    try {
      const response = await fetch(
        `http://localhost:8000/api/cart/${userId}/items/${productId}`,
        {
          method: 'DELETE',
          headers: accessToken ? { 'Authorization': `Bearer ${accessToken}` } : {}
        }
      );
      const data = await response.json();
      setItems(data.items);
      setTotalPrice(data.total_price);
    } catch (error) {
      console.error('Failed to remove item:', error);
    }
  };

  if (loading) return <div>Loading cart...</div>;

  if (items.length === 0) {
    return <div className="text-center py-8 text-gray-600">Your cart is empty</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Shopping Cart</h2>
      
      <div className="space-y-4 mb-6">
        {items.map(item => (
          <div key={item.product_id} className="flex gap-4 border-b pb-4">
            <Image
              src={item.image}
              alt={item.product_name}
              width={100}
              height={100}
              className="rounded object-cover"
            />
            <div className="flex-1">
              <h3 className="font-bold text-lg">{item.product_name}</h3>
              <p className="text-gray-600">${item.price.toFixed(2)}</p>
              
              <div className="flex gap-2 items-center mt-2">
                <button
                  onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                  className="px-2 py-1 bg-gray-300 rounded"
                >
                  -
                </button>
                <input
                  type="number"
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.product_id, parseInt(e.target.value) || 1)}
                  className="w-12 border border-gray-300 rounded text-center"
                />
                <button
                  onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                  className="px-2 py-1 bg-gray-300 rounded"
                >
                  +
                </button>
                <button
                  onClick={() => removeItem(item.product_id)}
                  className="ml-auto px-4 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                >
                  Remove
                </button>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-lg">${item.total.toFixed(2)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t pt-4 text-right">
        <p className="text-2xl font-bold">Total: ${totalPrice.toFixed(2)}</p>
        <button className="mt-4 px-6 py-3 bg-green-600 text-white font-bold rounded hover:bg-green-700">
          Checkout
        </button>
      </div>
    </div>
  );
}
```

---

## 4. Auth/Login Component

User authentication.

```typescript
// app/components/LoginForm.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginForm() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:8000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        throw new Error('Login failed');
      }

      const data = await response.json();
      
      // Store token and user info
      localStorage.setItem('access_token', data.access_token);
      localStorage.setItem('user_id', data.user.id.toString());
      localStorage.setItem('user_name', data.user.name);

      // Redirect to dashboard
      router.push('/dashboard');
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleLogin} className="space-y-4 max-w-md mx-auto">
      <h2 className="text-2xl font-bold">Login</h2>
      
      {error && <div className="text-red-600 text-sm">{error}</div>}
      
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
        className="w-full border border-gray-300 rounded px-4 py-2"
      />
      
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        required
        className="w-full border border-gray-300 rounded px-4 py-2"
      />
      
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 disabled:opacity-50"
      >
        {loading ? 'Logging in...' : 'Login'}
      </button>
    </form>
  );
}
```

---

## 5. ProductDetail Page

Full product page with images and reviews.

```typescript
// app/products/[slug]/page.tsx
'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';

export default function ProductDetail({ params }: { params: { slug: string } }) {
  const [product, setProduct] = useState<any>(null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchProduct = async () => {
    try {
      const response = await fetch(`http://localhost:8000/api/products/slug/${params.slug}`);
      const data = await response.json();
      setProduct(data);
    } catch (error) {
      console.error('Failed to load product:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="text-center py-8">Loading...</div>;
  if (!product) return <div className="text-center py-8">Product not found</div>;

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Images */}
        <div>
          <div className="relative h-96 bg-gray-100 rounded-lg mb-4">
            <Image
              src={product.images[selectedImage]}
              alt={product.name}
              fill
              className="object-cover rounded-lg"
            />
          </div>
          <div className="flex gap-2">
            {product.images.map((img: string, idx: number) => (
              <button
                key={idx}
                onClick={() => setSelectedImage(idx)}
                className={`relative w-20 h-20 rounded border-2 ${
                  idx === selectedImage ? 'border-blue-600' : 'border-gray-300'
                }`}
              >
                <Image src={img} alt="" fill className="object-cover rounded" />
              </button>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-4xl font-bold mb-4">{product.name}</h1>
          
          <div className="flex items-center gap-2 mb-4">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={i < Math.round(product.rating) ? 'text-yellow-400' : 'text-gray-300'}>
                ★
              </span>
            ))}
            <span className="text-gray-600">({product.rating})</span>
          </div>

          <p className="text-3xl font-bold text-gray-900 mb-4">${product.price.toFixed(2)}</p>
          
          <p className="text-gray-600 mb-6">{product.description}</p>

          <div className="mb-6">
            <span className={`inline-block px-4 py-2 rounded ${
              product.in_stock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {product.in_stock ? 'In Stock' : 'Out of Stock'}
            </span>
            <p className="text-sm text-gray-600 mt-2">Stock: {product.stock} units</p>
          </div>

          <div className="space-y-4">
            <div className="flex gap-4">
              <input
                type="number"
                min="1"
                max="10"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-24 border border-gray-300 rounded px-4 py-2"
              />
              <button className="flex-1 bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700">
                Add to Cart
              </button>
            </div>
            <button className="w-full border-2 border-blue-600 text-blue-600 font-bold py-2 rounded hover:bg-blue-50">
              Add to Wishlist
            </button>
          </div>

          <div className="mt-8 pt-8 border-t">
            <h2 className="text-xl font-bold mb-4">Product Details</h2>
            <dl className="space-y-2">
              <div className="flex justify-between">
                <dt className="font-semibold">Category:</dt>
                <dd>{product.category}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-semibold">SKU:</dt>
                <dd>PRD-{product.id}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="font-semibold">Shipping:</dt>
                <dd>Free on orders over $50</dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

## Integration Checklist

- [ ] Set up Next.js API routes to proxy requests
- [ ] Configure environment variables for API URL
- [ ] Add error boundaries
- [ ] Implement loading skeletons
- [ ] Add optimistic updates for cart
- [ ] Set up proper TypeScript types for all API responses
- [ ] Add tests for components
- [ ] Implement proper error handling
- [ ] Add accessibility features (ARIA labels, etc.)
- [ ] Optimize images with Next.js Image component

