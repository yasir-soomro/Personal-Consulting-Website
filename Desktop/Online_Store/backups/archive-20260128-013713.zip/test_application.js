// Test script to verify the application is working with all improvements
const axios = require('axios');

async function testApplication() {
  console.log('Testing application with all improvements...\n');
  
  try {
    // Test health endpoint
    console.log('1. Testing health endpoint...');
    const healthResponse = await axios.get('http://127.0.0.1:8000/health');
    console.log('✓ Health check passed:', healthResponse.data);
    
    // Test products endpoint
    console.log('\n2. Testing products endpoint...');
    const productsResponse = await axios.get('http://127.0.0.1:8000/products?limit=5');
    console.log('✓ Products endpoint works, received:', productsResponse.data.data.length, 'products');
    
    // Test users endpoint (should require authentication)
    console.log('\n3. Testing users endpoint (without auth)...');
    try {
      const usersResponse = await axios.get('http://127.0.0.1:8000/users');
      console.log('✓ Users endpoint accessible:', usersResponse.data.total, 'total users');
    } catch (usersErr) {
      console.log('Note: Users endpoint requires authentication (expected):', usersErr.response?.status);
    }
    
    // Test API documentation
    console.log('\n4. Testing API documentation endpoint...');
    const docsResponse = await axios.get('http://127.0.0.1:8000/docs');
    console.log('✓ API documentation accessible (status):', docsResponse.status);
    
    console.log('\n✓ Application is running correctly with all improvements!');
    console.log('\nFrontend is available at: http://localhost:3000');
    console.log('Backend API is available at: http://127.0.0.1:8000');
    console.log('API Documentation: http://127.0.0.1:8000/docs');
    
  } catch (error) {
    console.error('✗ Application test failed:', error.message);
  }
}

testApplication();