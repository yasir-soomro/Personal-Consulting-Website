// Test script to verify the ApiError fix
const axios = require('axios');

// Test the API endpoints to make sure they work
async function testAPIEndpoints() {
  console.log('Testing API endpoints after ApiError fix...\n');
  
  try {
    // Test health endpoint
    console.log('1. Testing health endpoint...');
    const healthResponse = await axios.get('http://127.0.0.1:8000/health');
    console.log('✓ Health check passed:', healthResponse.data);
    
    // Test products endpoint
    console.log('\n2. Testing products endpoint...');
    const productsResponse = await axios.get('http://127.0.0.1:8000/products');
    console.log('✓ Products endpoint works, received:', productsResponse.data.total, 'total products');
    
    console.log('\n✓ All tests passed! The ApiError issue should be resolved.');
    
  } catch (error) {
    console.error('✗ Test failed:', error.response?.data || error.message);
  }
}

testAPIEndpoints();