# E-Commerce Application Startup Script
# This script starts both the FastAPI backend and Next.js frontend

Write-Host "🚀 E-Commerce Application Startup" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Start Backend Server
Write-Host "Starting Backend API (FastAPI)..." -ForegroundColor Yellow
Start-Job -ScriptBlock {
    cd c:\Users\afzal\Desktop\Online_Store
    python -m uvicorn Backend_App.main:app --host 0.0.0.0 --port 8000 --reload
} -Name "backend"

Start-Sleep -Seconds 3

# Start Frontend Server
Write-Host "Starting Frontend (Next.js)..." -ForegroundColor Yellow
Start-Job -ScriptBlock {
    cd c:\Users\afzal\Desktop\Online_Store\Frontend_App\my-app
    npm run dev
} -Name "frontend"

Write-Host ""
Write-Host "✓ Both servers starting..." -ForegroundColor Green
Write-Host ""
Write-Host "📍 Frontend: http://localhost:3000" -ForegroundColor Green
Write-Host "📍 Backend API: http://localhost:8000" -ForegroundColor Green
Write-Host "📍 API Docs: http://localhost:8000/docs" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop all services" -ForegroundColor Gray
Write-Host ""

# Keep script running
while ($true) {
    Start-Sleep -Seconds 1
}
