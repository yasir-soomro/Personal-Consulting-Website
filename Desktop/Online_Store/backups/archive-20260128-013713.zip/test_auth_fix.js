// Test script to verify the AuthResponse fix
const axios = require('axios');

// Test the authentication endpoints to make sure they work correctly
async function testAuthEndpoints() {
  console.log('Testing authentication endpoints after AuthResponse fix...\n');
  
  try {
    // Test health endpoint first
    console.log('1. Testing health endpoint...');
    const healthResponse = await axios.get('http://127.0.0.1:8000/health');
    console.log('✓ Health check passed:', healthResponse.data);
    
    // Test registration endpoint
    console.log('\n2. Testing registration endpoint...');
    const randomEmail = `testuser_${Date.now()}@example.com`;
    try {
      const registerResponse = await axios.post('http://127.0.0.1:8000/auth/register', {
        email: randomEmail,
        name: 'Test User',
        password: 'password123'
      });
      console.log('✓ Registration successful:', registerResponse.data.user.name);
      console.log('  Token type:', registerResponse.data.token_type);
      console.log('  Has access token:', !!registerResponse.data.access_token);
    } catch (regErr) {
      console.log('Note: Registration may have failed if user already exists:', regErr.response?.data?.detail || regErr.message);
    }
    
    // Test login endpoint
    console.log('\n3. Testing login endpoint...');
    try {
      const loginResponse = await axios.post('http://127.0.0.1:8000/auth/login', {
        email: 'admin@example.com', // Using a default admin account if it exists
        password: 'password123'
      });
      console.log('✓ Login successful:', loginResponse.data.user?.name || 'User logged in');
      console.log('  Token type:', loginResponse.data.token_type);
      console.log('  Has access token:', !!loginResponse.data.access_token);
    } catch (loginErr) {
      console.log('Note: Login failed (expected if default user does not exist):', loginErr.response?.data?.detail || loginErr.message);
      
      // Try with the user we just registered (if registration worked)
      try {
        const loginResponse = await axios.post('http://127.0.0.1:8000/auth/login', {
          email: randomEmail,
          password: 'password123'
        });
        console.log('✓ Login with new user successful:', loginResponse.data.user?.name || 'User logged in');
        console.log('  Token type:', loginResponse.data.token_type);
        console.log('  Has access token:', !!loginResponse.data.access_token);
      } catch (newUserLoginErr) {
        console.log('Note: Login with new user also failed:', newUserLoginErr.response?.data?.detail || newUserLoginErr.message);
      }
    }
    
    console.log('\n✓ Authentication tests completed!');
    
  } catch (error) {
    console.error('✗ Authentication test failed:', error.response?.data || error.message);
  }
}

testAuthEndpoints();