# E-Commerce API Integration Guide

Complete API documentation and integration examples for the FastAPI backend.

## Base URL
```
http://localhost:8000/api
```

---

## Authentication

### Register New User
```http
POST /auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "name": "John Doe",
  "password": "SecurePassword123"
}
```

**Response (201 Created):**
```json
{
  "id": 1,
  "email": "user@example.com",
  "name": "John Doe",
  "is_active": true,
  "created_at": "2024-01-15T10:30:00"
}
```

**JavaScript Example:**
```typescript
async function register(email: string, name: string, password: string) {
  const response = await fetch('http://localhost:8000/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, name, password })
  });
  return response.json();
}
```

---

### Login User
```http
POST /auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePassword123"
}
```

**Response (200 OK):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "id": 1,
    "email": "user@example.com",
    "name": "John Doe",
    "is_active": true,
    "created_at": "2024-01-15T10:30:00"
  }
}
```

**JavaScript Example:**
```typescript
async function login(email: string, password: string) {
  const response = await fetch('http://localhost:8000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await response.json();
  // Store token in localStorage
  localStorage.setItem('access_token', data.access_token);
  return data;
}
```

---

## Products

### Get All Categories
```http
GET /products/categories
```

**Response:**
```json
{
  "data": [
    "Electronics",
    "Fashion",
    "Home",
    "Beauty",
    "Sports",
    "Books"
  ],
  "total": 6
}
```

**JavaScript Example:**
```typescript
async function getCategories() {
  const response = await fetch('http://localhost:8000/api/products/categories');
  return response.json();
}
```

---

### List Products (with Filtering & Pagination)
```http
GET /products?skip=0&limit=10&search=laptop&category=Electronics&min_price=500&max_price=2000&min_rating=4&in_stock=true&sort_by=price
```

**Query Parameters:**
- `skip`: Number of products to skip (default: 0)
- `limit`: Number of products per page (default: 10, max: 100)
- `search`: Search term in name/description
- `category`: Filter by category
- `min_price`: Minimum price
- `max_price`: Maximum price
- `min_rating`: Minimum rating (0-5)
- `in_stock`: Only show in-stock items (true/false)
- `sort_by`: `id`, `price`, `price_desc`, `rating`, `stock`, `name`

**Response:**
```json
{
  "data": [
    {
      "id": 1,
      "name": "Wireless Headphones",
      "slug": "wireless-headphones",
      "description": "High-quality wireless headphones with noise cancellation",
      "price": 149.99,
      "stock": 45,
      "category": "Electronics",
      "rating": 4.8,
      "images": [
        "https://picsum.photos/500/500?random=1",
        "https://picsum.photos/500/500?random=2",
        "https://picsum.photos/500/500?random=3"
      ],
      "in_stock": true,
      "created_at": "2024-01-15T10:30:00"
    }
  ],
  "total": 42,
  "skip": 0,
  "limit": 10,
  "total_pages": 5
}
```

**JavaScript Example:**
```typescript
interface Product {
  id: number;
  name: string;
  slug: string;
  price: number;
  stock: number;
  category: string;
  rating: number;
  images: string[];
  in_stock: boolean;
}

async function getProducts(filters: {
  search?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  inStock?: boolean;
  sortBy?: string;
  skip?: number;
  limit?: number;
}): Promise<{ data: Product[]; total: number; total_pages: number }> {
  const params = new URLSearchParams();
  if (filters.search) params.append('search', filters.search);
  if (filters.category) params.append('category', filters.category);
  if (filters.minPrice) params.append('min_price', filters.minPrice.toString());
  if (filters.maxPrice) params.append('max_price', filters.maxPrice.toString());
  if (filters.minRating) params.append('min_rating', filters.minRating.toString());
  if (filters.inStock) params.append('in_stock', 'true');
  params.append('sort_by', filters.sortBy || 'id');
  params.append('skip', (filters.skip || 0).toString());
  params.append('limit', (filters.limit || 10).toString());

  const response = await fetch(`http://localhost:8000/api/products?${params}`);
  return response.json();
}
```

---

### Get Product by Slug
```http
GET /products/slug/wireless-headphones
```

**Response:**
```json
{
  "id": 1,
  "name": "Wireless Headphones",
  "slug": "wireless-headphones",
  "description": "High-quality wireless headphones with noise cancellation",
  "price": 149.99,
  "stock": 45,
  "category": "Electronics",
  "rating": 4.8,
  "images": ["https://picsum.photos/500/500?random=1", ...],
  "in_stock": true,
  "created_at": "2024-01-15T10:30:00",
  "reviews_count": 0,
  "discount_percentage": null
}
```

**JavaScript Example:**
```typescript
async function getProductBySlug(slug: string) {
  const response = await fetch(`http://localhost:8000/api/products/slug/${slug}`);
  return response.json();
}
```

---

### Get Product by ID
```http
GET /products/1
```

**Response:** Same as slug endpoint

---

### Create Product (Admin)
```http
POST /products
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "name": "New Product",
  "description": "Product description",
  "price": 99.99,
  "stock": 100,
  "category": "Electronics",
  "rating": 0.0,
  "images": ["image_url1", "image_url2"]
}
```

---

## Shopping Cart

### Get Cart
```http
GET /cart/1
```

**Response:**
```json
{
  "user_id": 1,
  "items": [
    {
      "product_id": 1,
      "product_name": "Wireless Headphones",
      "quantity": 2,
      "price": 149.99,
      "total": 299.98,
      "image": "https://picsum.photos/500/500?random=1"
    }
  ],
  "total_items": 2,
  "total_price": 299.98,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T11:45:00"
}
```

**JavaScript Example:**
```typescript
async function getCart(userId: number) {
  const token = localStorage.getItem('access_token');
  const response = await fetch(`http://localhost:8000/api/cart/${userId}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  return response.json();
}
```

---

### Add to Cart
```http
POST /cart/1/items
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "product_id": 1,
  "quantity": 2
}
```

**Response (201 Created):**
```json
{
  "user_id": 1,
  "items": [...],
  "total_items": 2,
  "total_price": 299.98,
  "created_at": "2024-01-15T10:30:00",
  "updated_at": "2024-01-15T11:45:00"
}
```

**JavaScript Example:**
```typescript
async function addToCart(userId: number, productId: number, quantity: number) {
  const token = localStorage.getItem('access_token');
  const response = await fetch(`http://localhost:8000/api/cart/${userId}/items`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ product_id: productId, quantity })
  });
  return response.json();
}
```

---

### Update Cart Item Quantity
```http
PUT /cart/1/items/1
Content-Type: application/json
Authorization: Bearer {access_token}

{
  "quantity": 3
}
```

**Response:** Updated cart object

**JavaScript Example:**
```typescript
async function updateCartItem(userId: number, productId: number, quantity: number) {
  const token = localStorage.getItem('access_token');
  const response = await fetch(`http://localhost:8000/api/cart/${userId}/items/${productId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ quantity })
  });
  return response.json();
}
```

---

### Remove Item from Cart
```http
DELETE /cart/1/items/1
Authorization: Bearer {access_token}
```

**Response:** Updated cart object

**JavaScript Example:**
```typescript
async function removeFromCart(userId: number, productId: number) {
  const token = localStorage.getItem('access_token');
  const response = await fetch(`http://localhost:8000/api/cart/${userId}/items/${productId}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` }
  });
  return response.json();
}
```

---

### Clear Entire Cart
```http
DELETE /cart/1/clear
Authorization: Bearer {access_token}
```

**Response:** Empty cart object

---

### Get Cart Summary
```http
GET /cart/1/summary
Authorization: Bearer {access_token}
```

**Response:**
```json
{
  "total_items": 2,
  "total_price": 299.98,
  "item_count": 1,
  "average_price": 149.99
}
```

---

## Error Responses

All errors follow this format:

```json
{
  "detail": "Error message explaining what went wrong"
}
```

**Common Status Codes:**
- `200 OK` - Successful request
- `201 Created` - Resource created successfully
- `204 No Content` - Successful delete
- `400 Bad Request` - Invalid input
- `401 Unauthorized` - Missing or invalid token
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

---

## Sample Products

The API comes with 30 pre-loaded products:

**Electronics (5):** Wireless Headphones, USB-C Hub, Mechanical Keyboard, 4K Webcam, Portable SSD
**Fashion (5):** Cotton T-Shirt, Denim Jeans, Winter Jacket, Running Shoes, Baseball Cap
**Home (5):** Wall Clock, Table Lamp, Coffee Maker, Bath Mat, Door Shelf
**Beauty (5):** Face Moisturizer, Shampoo Bottle, Lipstick, Eye Shadow Palette, Face Mask
**Sports (5):** Yoga Mat, Dumbbell Set, Basketball, Tennis Racket, Running Watch
**Books (5):** Python Programming, JavaScript Guide, Web Design, Data Science, Mobile Apps

Each product has:
- Realistic pricing
- Product description
- Stock quantity
- Star rating (2.0-5.0)
- 3 high-quality product images (from picsum.photos)
- URL-friendly slug

---

## Testing with cURL

**Register:**
```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","name":"Test User","password":"Password123"}'
```

**Login:**
```bash
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"Password123"}'
```

**Get Products:**
```bash
curl http://localhost:8000/api/products?category=Electronics&limit=5
```

**Add to Cart (using token):**
```bash
curl -X POST http://localhost:8000/api/cart/1/items \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{"product_id":1,"quantity":2}'
```

---

## Production Deployment Checklist

- [ ] Set `SECRET_KEY` environment variable for JWT signing
- [ ] Configure database (PostgreSQL/MongoDB) in `services/*.py`
- [ ] Set up CORS for production domain
- [ ] Enable HTTPS/SSL
- [ ] Configure email service for password reset
- [ ] Set up logging and monitoring
- [ ] Add rate limiting
- [ ] Enable request validation
- [ ] Configure API documentation at `/docs`

